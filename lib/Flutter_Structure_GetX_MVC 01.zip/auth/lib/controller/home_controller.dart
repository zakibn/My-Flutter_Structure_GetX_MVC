import 'package:get/get.dart';

class HomeController extends GetxController {
  final title = '39'.tr;
}
