import 'package:get/get_utils/get_utils.dart';

import '../../../core/constant/imgaeasset.dart';
import '../../model/onboardingmodel.dart';

List<OnBoardingModel> onBoardingList = [
  OnBoardingModel(
    title: "2".tr,
    body: "3".tr,
    image: AppImageAsset.onBoardingImageOne,
  ),
  OnBoardingModel(
    title: "4".tr,
    body: "3".tr,
    image: AppImageAsset.onBoardingImageTwo,
  ),
  OnBoardingModel(
    title: "6".tr,
    body: "3".tr,
    image: AppImageAsset.onBoardingImageThree,
  ),
  OnBoardingModel(
    title: "40".tr,
    body: "3".tr,
    image: AppImageAsset.onBoardingImageFour,
  ),
];
